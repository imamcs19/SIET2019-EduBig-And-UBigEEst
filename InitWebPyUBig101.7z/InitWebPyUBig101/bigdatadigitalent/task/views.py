from django.shortcuts import render

# Create your views here.
def index(request):
	return render(request, 'index.html')

def function_week1(request):
	if request.method == 'POST':
		import pandas as pd
		import numpy as np
		dataset = request.FILES['inputDataset']#'E:/Pak Imam/Digitalent/dataset_dump.csv'
		persentase_data_training = 90
		banyak_fitur = int(request.POST['banyakFitur'])
		banyak_hidden_neuron = int(request.POST['banyakHiddenNeuron'])

		dataset = pd.read_csv(dataset, delimiter=';', names = ['Tanggal', 'Harga'], usecols=['Harga'])
		minimum = int(dataset.min()-10000)
		maksimum = int(dataset.max()+10000)
		new_banyak_fitur = banyak_fitur + 1
		hasil_fitur = []
		for i in range((len(dataset)-new_banyak_fitur)+1):
			kolom = []
			j = i
			while j < (i+new_banyak_fitur):
				kolom.append(dataset.values[j][0])
				j += 1
			hasil_fitur.append(kolom)
		hasil_fitur = np.array(hasil_fitur)
		data_normalisasi = (hasil_fitur - minimum)/(maksimum - minimum)

		data_training = data_normalisasi[:int(persentase_data_training*len(data_normalisasi)/100)]
		data_testing = data_normalisasi[int(persentase_data_training*len(data_normalisasi)/100):]

		#Training
		bobot = np.random.rand(banyak_hidden_neuron, banyak_fitur)
		bias = np.random.rand(banyak_hidden_neuron)
		h = 1/(1 + np.exp(-(np.dot(data_training[:, :banyak_fitur], np.transpose(bobot)) + bias)))
		h_plus = np.dot(np.linalg.inv(np.dot(np.transpose(h),h)),np.transpose(h))
		output_weight = np.dot(h_plus, data_training[:, banyak_fitur])

		#Testing
		h = 1/(1 + np.exp(-(np.dot(data_testing[:, :banyak_fitur], np.transpose(bobot)) + bias)))
		predict = np.dot(h, output_weight)
		predict = predict * (maksimum - minimum) + minimum

		#MAPE
		aktual = np.array(hasil_fitur[int(persentase_data_training*len(data_normalisasi)/100):, banyak_fitur])
		mape = np.sum(np.abs(((aktual - predict)/aktual)*100))/len(predict)
		return render(request, 'week1.html', {
		'y_aktual' : list(aktual),
		'y_prediksi' : list(predict),
		'mape' : mape
	})
	else:
		return render(request, 'week1.html')

def function_week2_task1(request):
	return render(request, 'week21.html')

def function_week2_task2(request):
	return render(request, 'week22.html')

def function_week3(request):
	# Import library request
	import requests
	apikey = '133559c63e055b23b0dd2dafc698fcfe' # --> imam, 
	# tlg masing" sign up mandiri ke https://openweathermap.org/appid
	weather_url = "http://api.openweathermap.org/data/2.5/weather" # get kondisi saat ini
	#weather_url = "http://api.openweathermap.org/data/2.5/forecast" # get untuk peramalannya
	city_name = "Malang"
	# print(weather_url)
	#r = requests.get(weather_url, params={'q': city_name, 'APPID': apikey})
	r = requests.get(weather_url, params={'q': city_name, 'APPID': apikey})
	r.url # `requests` help us encode the URL in the correct format
	r.status_code # 200 means success
	result = r.json()
	return render(request, 'week3.html', {
		'result': result,
		'celcius': result['main']['temp']-273.15
	})

def function_week4(request):
	return render(request, 'week4.html')

def function_week5(request):
	return render(request, 'week5.html')

def function_week6(request):
	return render(request, 'week6.html')

def function_week7(request):
	return render(request, 'week7.html')

def function_week8(request):
	return render(request, 'week8.html')